=== Harrix MardownFile ===
Contributors: Harrix
Donate link: http://jason.stallin.gs
Tags: markdown, github,  shortcode, markdown, embed
Requires at least: 3.0.1
Tested up to: 4.4
Stable tag: 4.4
License: MIT
License URI: https://raw.github.com/Harrix/Harrix-MardownFile/README.md

Display Markdown files with syntax highlighting in Wordpress.

== Description ==

Harrix MardownFile is a plugin to display Markdown files with syntax highlighting in Wordpress.

Demo: [http://blog.harrix.org/?p=1336](http://blog.harrix.org/?p=1336)

The plugin uses the libraries:
* php-markdown: [https://github.com/michelf/php-markdown](https://github.com/michelf/php-markdown)
* highlightjs.org: [https://highlightjs.org/](https://highlightjs.org)

Usage:

**markdown**

This shortcode embeds markdown file by url. 

`[markdown]https://raw.github.com/Harrix/HarrixQtLibrary/master/README.md[/markdown]`

== Changelog ==

= 1.0 =
* First Version.